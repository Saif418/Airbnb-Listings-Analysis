-- room type counts, they are not equal so analysis will not be very strong for certain roomtypes

CREATE VIEW london_roomtype_count AS
SELECT 
    DISTINCT room_type,
    COUNT(room_type) AS count
FROM
    'london'
GROUP BY room_type

CREATE VIEW nyc_roomtype_count AS
SELECT 
    DISTINCT room_type,
    COUNT(room_type) AS count
FROM
    'nyc'
GROUP BY room_type

CREATE VIEW san_francisco_roomtype_count AS
SELECT 
    DISTINCT room_type,
    COUNT(room_type) AS count
FROM
    'san_francisco'
GROUP BY room_type
