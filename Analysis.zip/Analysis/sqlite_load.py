import sqlite3
import pandas as pd 

nyc_listings = pd.read_csv('Analysis/raw_data/New York Airbnb Listings.csv')
london_listings = pd.read_csv('Analysis/raw_data/London Airbnb Listings.csv')
sanfrancisco_listings = pd.read_csv('Analysis/raw_data/San Francisco Airbnb Listings.csv')


# Create SQLite database and connection
connection = sqlite3.connect("airbnb.db")
nyc_listings.to_sql("nyc", connection, if_exists="replace", index=False)
london_listings.to_sql("london", connection, if_exists="replace", index=False)
sanfrancisco_listings.to_sql("san_francisco", connection, if_exists="replace", index=False)

# Close the connection
connection.close()


